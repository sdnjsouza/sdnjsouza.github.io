function calcularImc() {
    //teste()

    var quilos = parseFloat(document.getElementById("peso").value)
    var metros = parseFloat(document.getElementById("altura").value)
  
   var imc = quilos / (metros*metros) 
   
   

    if (imc< 18.5) {
        document.getElementById("result").innerHTML = "Abaixo do Peso!!"

    } else if(imc>=18.5 && imc<=24.9 ) {
        document.getElementById("result").innerHTML = "Normal"
    }else if(imc > 24.9 ) {
        document.getElementById("result").innerHTML = "Acima do Peso!!"
    }
 alert( "IMC ->" +imc.toFixed(3))
}
/*
function imc(a, b) {
    parseFloat(a)
    parseFloat(b)
    var imcCalc = a / (b * b)
    return imcCalc
}*/

